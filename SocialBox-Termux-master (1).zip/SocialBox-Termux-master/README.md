# SocialBox-Termux
SocialBox is a Bruteforce Attack Framework [ Facebook , Gmail , Instagram ,Twitter ] , Coded By Belahsan Ouerghi Edit By samsesh
# Installation
```
apt-get update
apt-get install git
git clone https://github.com/samsesh/SocialBox-Termux.git 
cd SocialBox-Termux
chmod +x install-sb.sh
./install-sb.sh
```
# Run
```
./SocialBox.sh
```
# Screenshots :
![Test Image 8](https://github.com/samsesh/SocialBox-Termux/blob/master/Screenshots/sb.png)
# Tested On :
* Termux on andriod (tor connected if use vpn )
## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=samsesh/SocialBox-Termux&type=Date)](https://star-history.com/#samsesh/SocialBox-Termux&Date)
### Donate
- If this project very help you to penetration testing  and u want support me , you can give me a cup of coffee :)
- [doante page](https://github.com/samsesh/donate)
# for any os :
* [socialbox](https://github.com/samsesh/SocialBox)
# Contact
* [Twitter](https://www.twitter.com/_samsesh) - _samsesh
* [Instagram](https://www.instagram.com/sam.sesh) - sam.sesh
# Authors :
* facebook  : Imad
* gmail     : Ha3MrX
* instagram : thelinuxchoice
* Twitter   : thelinuxchoice
* SocialBox : samsesh
* SocialBox-Termux : samsesh
